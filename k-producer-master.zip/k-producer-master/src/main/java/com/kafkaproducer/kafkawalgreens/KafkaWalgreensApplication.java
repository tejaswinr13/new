package com.kafkaproducer.kafkawalgreens;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaWalgreensApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaWalgreensApplication.class, args);
	}

}
