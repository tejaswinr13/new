package com.kafkaproducer.kafkawalgreens.controller;

import com.kafkaproducer.kafkawalgreens.Service.ProducerService;
import com.kafkaproducer.kafkawalgreens.model.PatientID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
//
@RestController
@RequestMapping("/jsontoxml")
public class ProducerController {

    @Autowired
    ProducerService producerService;
    @PostMapping("/convert")
    public String saveUserDetails (@RequestBody PatientID jsonString) throws JsonProcessingException {


        XmlMapper xmlMapper = new XmlMapper();
       String xmlString = xmlMapper.writeValueAsString(jsonString);
        producerService.userDetails(xmlString);

        System.out.println("Request sent to kafka broker :: "+xmlString);
        return "Patient id sent to kafka broker";
    }

}
