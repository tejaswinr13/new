package com.kafkaproducer.kafkawalgreens.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class ProducerService {
    @Autowired
    private KafkaTemplate<String, String> userDetailsKafkaTemplate;

    @Value(value = "${kafka.topic-one}")
    private String topicOne="topicOne";

    public void userDetails(String userDetails) {

       userDetailsKafkaTemplate.send(topicOne, userDetails);
    }


}
