package com.kafkaproducer.kafkawalgreens;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaWalgreensApplicationTests {

	@Test
	void contextLoads() {
	}

}
